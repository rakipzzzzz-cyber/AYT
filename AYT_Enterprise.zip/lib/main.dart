import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

const rose = Color(0xFFD81B60);
String tk(num v) => '৳${v.toStringAsFixed(v % 1 == 0 ? 0 : 2)}';
String uid() => DateTime.now().microsecondsSinceEpoch.toString();
String dstr(DateTime d) => '${d.day}/${d.month}/${d.year}';

class Product {
  String id, name, cat;
  double buy, sell;
  int stock;
  String? img;
  Product({required this.id, required this.name, this.cat = 'সাধারণ', this.buy = 0, this.sell = 0, this.stock = 0, this.img});
  Map toJson() => {'id': id, 'name': name, 'cat': cat, 'buy': buy, 'sell': sell, 'stock': stock, 'img': img};
  factory Product.from(Map m) => Product(id: m['id'], name: m['name'], cat: m['cat'], buy: (m['buy'] as num).toDouble(), sell: (m['sell'] as num).toDouble(), stock: m['stock'], img: m['img']);
}

class Line {
  String pid, name;
  int qty;
  double price, cost;
  Line(this.pid, this.name, this.qty, this.price, this.cost);
  Map toJson() => {'pid': pid, 'name': name, 'qty': qty, 'price': price, 'cost': cost};
  factory Line.from(Map m) => Line(m['pid'], m['name'], m['qty'], (m['price'] as num).toDouble(), (m['cost'] as num).toDouble());
}

class Order {
  String id, customer, phone, address, status, src; // status: pending/done/cancel, src: shop/pos
  DateTime date;
  List<Line> lines;
  double discount, paid;
  Order({required this.id, required this.date, required this.customer, this.phone = '', this.address = '', this.status = 'pending', this.src = 'shop', required this.lines, this.discount = 0, this.paid = 0});
  double get sub => lines.fold(0.0, (s, l) => s + l.qty * l.price);
  double get total => sub - discount;
  double get due => total - paid;
  double get cost => lines.fold(0.0, (s, l) => s + l.qty * l.cost);
  Map toJson() => {'id': id, 'date': date.toIso8601String(), 'customer': customer, 'phone': phone, 'address': address, 'status': status, 'src': src, 'lines': lines.map((e) => e.toJson()).toList(), 'discount': discount, 'paid': paid};
  factory Order.from(Map m) => Order(id: m['id'], date: DateTime.parse(m['date']), customer: m['customer'], phone: m['phone'], address: m['address'], status: m['status'], src: m['src'], lines: (m['lines'] as List).map((e) => Line.from(e)).toList(), discount: (m['discount'] as num).toDouble(), paid: (m['paid'] as num).toDouble());
}

class Expense {
  String id, title;
  DateTime date;
  double amount;
  Expense(this.id, this.title, this.amount, this.date);
  Map toJson() => {'id': id, 'title': title, 'amount': amount, 'date': date.toIso8601String()};
  factory Expense.from(Map m) => Expense(m['id'], m['title'], (m['amount'] as num).toDouble(), DateTime.parse(m['date']));
}

class Store extends ChangeNotifier {
  late SharedPreferences p;
  List<Product> products = [];
  List<Order> orders = [];
  List<Expense> expenses = [];
  Map<String, int> cart = {}, pos = {};
  ThemeMode mode = ThemeMode.system;
  String adminPin = '1234', accPin = '5678';

  Future<void> load() async {
    p = await SharedPreferences.getInstance();
    products = (jsonDecode(p.getString('products') ?? '[]') as List).map((e) => Product.from(e)).toList();
    orders = (jsonDecode(p.getString('orders') ?? '[]') as List).map((e) => Order.from(e)).toList();
    expenses = (jsonDecode(p.getString('expenses') ?? '[]') as List).map((e) => Expense.from(e)).toList();
    mode = ThemeMode.values[p.getInt('mode') ?? 0];
    adminPin = p.getString('adminPin') ?? '1234';
    accPin = p.getString('accPin') ?? '5678';
  }

  void save() {
    p.setString('products', jsonEncode(products.map((e) => e.toJson()).toList()));
    p.setString('orders', jsonEncode(orders.map((e) => e.toJson()).toList()));
    p.setString('expenses', jsonEncode(expenses.map((e) => e.toJson()).toList()));
    p.setInt('mode', mode.index);
    p.setString('adminPin', adminPin);
    p.setString('accPin', accPin);
    notifyListeners();
  }

  Product? prod(String id) {
    for (final x in products) {
      if (x.id == id) return x;
    }
    return null;
  }

  List<Line> linesOf(Map<String, int> c) => c.entries.where((e) => prod(e.key) != null).map((e) {
        final x = prod(e.key)!;
        return Line(x.id, x.name, e.value, x.sell, x.buy);
      }).toList();

  void takeStock(Order o) {
    for (final l in o.lines) {
      final x = prod(l.pid);
      if (x != null) x.stock = (x.stock - l.qty).clamp(0, 1 << 30);
    }
  }

  String memo(Order o) {
    final b = StringBuffer('🌸 AYT এন্টারপ্রাইজ\nমেমো নং: ${o.id.substring(o.id.length - 6)}\nতারিখ: ${dstr(o.date)}\nগ্রাহক: ${o.customer} ${o.phone}\n----------------\n');
    for (final l in o.lines) {
      b.writeln('${l.name} × ${l.qty} = ${tk(l.qty * l.price)}');
    }
    b.write('----------------\nমোট: ${tk(o.sub)}\nছাড়: ${tk(o.discount)}\nবিল: ${tk(o.total)}\nজমা: ${tk(o.paid)}\nবাকি: ${tk(o.due)}\n\nধন্যবাদ, আবার আসবেন!');
    return b.toString();
  }
}

final store = Store();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await store.load();
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  ThemeData th(Brightness b) => ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: rose, brightness: b, surface: b == Brightness.dark ? const Color(0xFF14090E) : const Color(0xFFFFF8FA)),
        cardTheme: CardTheme(elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)), color: b == Brightness.dark ? const Color(0xFF2A1520) : Colors.white),
        inputDecorationTheme: InputDecorationTheme(border: OutlineInputBorder(borderRadius: BorderRadius.circular(14))),
      );
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: store,
        builder: (_, __) => MaterialApp(title: 'AYT এন্টারপ্রাইজ', debugShowCheckedModeBanner: false, theme: th(Brightness.light), darkTheme: th(Brightness.dark), themeMode: store.mode, home: const Home()),
      );
}

void snack(BuildContext c, String m) => ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating));

Future<bool> askPin(BuildContext c, String pin) async {
  final t = TextEditingController();
  final ok = await showDialog<bool>(
    context: c,
    builder: (d) => AlertDialog(
      title: const Text('পাসওয়ার্ড দিন'),
      content: TextField(controller: t, obscureText: true, keyboardType: TextInputType.number, autofocus: true),
      actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('বাতিল')), FilledButton(onPressed: () => Navigator.pop(d, t.text == pin), child: const Text('ঢুকুন'))],
    ),
  );
  if (ok != true && c.mounted && t.text.isNotEmpty) snack(c, 'পাসওয়ার্ড ভুল');
  return ok == true;
}

Widget thumb(Product x, double s) {
  final f = x.img != null && File(x.img!).existsSync();
  return ClipRRect(borderRadius: BorderRadius.circular(14), child: SizedBox(width: s, height: s, child: f ? Image.file(File(x.img!), fit: BoxFit.cover) : Container(color: rose.withOpacity(.12), child: const Icon(Icons.shopping_bag_outlined, color: rose))));
}

class Home extends StatelessWidget {
  const Home({super.key});
  Widget tile(BuildContext c, IconData i, String t, String s, VoidCallback f) => Card(
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: f,
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(children: [
              CircleAvatar(radius: 28, backgroundColor: rose.withOpacity(.12), child: Icon(i, color: rose, size: 28)),
              const SizedBox(width: 16),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(t, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700)), Text(s, style: TextStyle(color: Theme.of(c).hintColor))])),
              const Icon(Icons.chevron_right),
            ]),
          ),
        ),
      );
  @override
  Widget build(BuildContext c) => Scaffold(
        body: ListView(padding: EdgeInsets.zero, children: [
          Container(
            padding: EdgeInsets.fromLTRB(24, MediaQuery.of(c).padding.top + 16, 24, 34),
            decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFFAD1457), Color(0xFFEC407A)], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.vertical(bottom: Radius.circular(36))),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Align(alignment: Alignment.centerRight, child: IconButton(icon: const Icon(Icons.settings, color: Colors.white), onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const Settings())))),
              const Text('AYT', style: TextStyle(color: Colors.white, fontSize: 46, fontWeight: FontWeight.w900, letterSpacing: 2)),
              const Text('এন্টারপ্রাইজ', style: TextStyle(color: Colors.white70, fontSize: 22)),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.all(18),
            child: Column(children: [
              tile(c, Icons.storefront, 'কাস্টমার', 'পণ্য দেখুন ও অর্ডার করুন', () => Navigator.push(c, MaterialPageRoute(builder: (_) => const Shop()))),
              const SizedBox(height: 12),
              tile(c, Icons.admin_panel_settings, 'অ্যাডমিন', 'পণ্য, অর্ডার ও বিক্রি', () async {
                if (await askPin(c, store.adminPin) && c.mounted) Navigator.push(c, MaterialPageRoute(builder: (_) => const Admin()));
              }),
              const SizedBox(height: 12),
              tile(c, Icons.bar_chart_rounded, 'হিসাব', 'বিক্রি, খরচ, লাভ ও বাকি', () async {
                if (await askPin(c, store.accPin) && c.mounted) Navigator.push(c, MaterialPageRoute(builder: (_) => const Accounts()));
              }),
            ]),
          ),
        ]),
      );
}

class Settings extends StatelessWidget {
  const Settings({super.key});
  void changePin(BuildContext c, bool admin) {
    final t = TextEditingController();
    showDialog(
      context: c,
      builder: (d) => AlertDialog(
        title: Text(admin ? 'নতুন অ্যাডমিন পাসওয়ার্ড' : 'নতুন হিসাব পাসওয়ার্ড'),
        content: TextField(controller: t, keyboardType: TextInputType.number, autofocus: true),
        actions: [
          FilledButton(onPressed: () {
            if (t.text.length < 4) return;
            admin ? store.adminPin = t.text : store.accPin = t.text;
            store.save();
            Navigator.pop(d);
          }, child: const Text('সংরক্ষণ')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('সেটিংস')),
        body: ListenableBuilder(
          listenable: store,
          builder: (_, __) => ListView(padding: const EdgeInsets.all(18), children: [
            const Text('থিম', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const SizedBox(height: 10),
            SegmentedButton<ThemeMode>(
              segments: const [ButtonSegment(value: ThemeMode.light, label: Text('লাইট')), ButtonSegment(value: ThemeMode.dark, label: Text('ডার্ক')), ButtonSegment(value: ThemeMode.system, label: Text('সিস্টেম'))],
              selected: {store.mode},
              onSelectionChanged: (s) {
                store.mode = s.first;
                store.save();
              },
            ),
            const SizedBox(height: 24),
            ListTile(leading: const Icon(Icons.lock), title: const Text('অ্যাডমিন পাসওয়ার্ড বদলান'), onTap: () => changePin(c, true)),
            ListTile(leading: const Icon(Icons.lock), title: const Text('হিসাব পাসওয়ার্ড বদলান'), onTap: () => changePin(c, false)),
          ]),
        ),
      );
}

// ---------- কাস্টমার ----------
class Shop extends StatefulWidget {
  const Shop({super.key});
  @override
  State<Shop> createState() => _ShopState();
}

class _ShopState extends State<Shop> {
  String q = '', cat = 'সব';
  @override
  Widget build(BuildContext c) => ListenableBuilder(
        listenable: store,
        builder: (_, __) {
          final cats = ['সব', ...{...store.products.map((e) => e.cat)}];
          final list = store.products.where((x) => (cat == 'সব' || x.cat == cat) && x.name.toLowerCase().contains(q.toLowerCase())).toList();
          final n = store.cart.values.fold(0, (a, b) => a + b);
          return Scaffold(
            appBar: AppBar(title: const Text('আমাদের পণ্য'), actions: [IconButton(icon: const Icon(Icons.receipt_long), tooltip: 'আমার অর্ডার', onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const MyOrders())))]),
            floatingActionButton: n == 0 ? null : FloatingActionButton.extended(onPressed: () => checkout(c, store.cart, false), icon: const Icon(Icons.shopping_cart), label: Text('কার্ট ($n)')),
            body: Column(children: [
              Padding(padding: const EdgeInsets.fromLTRB(14, 6, 14, 6), child: TextField(decoration: const InputDecoration(hintText: 'পণ্য খুঁজুন', prefixIcon: Icon(Icons.search)), onChanged: (v) => setState(() => q = v))),
              SizedBox(height: 42, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 10), children: cats.map((e) => Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: ChoiceChip(label: Text(e), selected: cat == e, onSelected: (_) => setState(() => cat = e)))).toList())),
              Expanded(
                child: list.isEmpty
                    ? const Center(child: Text('এখনো কোনো পণ্য নেই'))
                    : GridView.builder(
                        padding: const EdgeInsets.all(14),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .68),
                        itemCount: list.length,
                        itemBuilder: (_, i) {
                          final x = list[i];
                          return Card(
                            child: Padding(
                              padding: const EdgeInsets.all(10),
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Expanded(child: LayoutBuilder(builder: (_, k) => thumb(x, k.maxWidth))),
                                const SizedBox(height: 8),
                                Text(x.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
                                Row(children: [
                                  Text(tk(x.sell), style: const TextStyle(color: rose, fontWeight: FontWeight.w800, fontSize: 17)),
                                  const Spacer(),
                                  x.stock <= 0
                                      ? const Text('শেষ', style: TextStyle(color: Colors.grey))
                                      : IconButton.filled(visualDensity: VisualDensity.compact, icon: const Icon(Icons.add), onPressed: () {
                                          store.cart[x.id] = (store.cart[x.id] ?? 0) + 1;
                                          store.notifyListeners();
                                        }),
                                ]),
                              ]),
                            ),
                          );
                        },
                      ),
              ),
            ]),
          );
        },
      );
}

class MyOrders extends StatelessWidget {
  const MyOrders({super.key});
  @override
  Widget build(BuildContext c) {
    final l = store.orders.where((o) => o.src == 'shop').toList().reversed.toList();
    const st = {'pending': 'অপেক্ষমাণ', 'done': 'সম্পন্ন', 'cancel': 'বাতিল'};
    return Scaffold(
      appBar: AppBar(title: const Text('আমার অর্ডার')),
      body: l.isEmpty ? const Center(child: Text('কোনো অর্ডার নেই')) : ListView(padding: const EdgeInsets.all(14), children: l.map((o) => Card(child: ListTile(title: Text('${tk(o.total)} • ${o.lines.length}টি পণ্য'), subtitle: Text(dstr(o.date)), trailing: Chip(label: Text(st[o.status]!))))).toList()),
    );
  }
}

// চেকআউট (কাস্টমার অর্ডার ও অ্যাডমিন বিক্রি দুটোর জন্য)
void checkout(BuildContext c, Map<String, int> cart, bool isPos) {
  final lines = store.linesOf(cart);
  final name = TextEditingController(), phone = TextEditingController(), addr = TextEditingController(), disc = TextEditingController(text: '0'), paid = TextEditingController();
  showModalBottomSheet(
    context: c,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (d) => StatefulBuilder(builder: (d, set) {
      final sub = lines.fold(0.0, (s, l) => s + l.qty * l.price);
      final dv = double.tryParse(disc.text) ?? 0;
      return Padding(
        padding: EdgeInsets.fromLTRB(18, 0, 18, MediaQuery.of(d).viewInsets.bottom + 18),
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            ...lines.map((l) => ListTile(
                  dense: true,
                  title: Text(l.name),
                  subtitle: Text('${tk(l.price)} × ${l.qty}'),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    IconButton(icon: const Icon(Icons.remove_circle_outline), onPressed: () {
                      l.qty--;
                      if (l.qty <= 0) {
                        cart.remove(l.pid);
                        lines.remove(l);
                      } else {
                        cart[l.pid] = l.qty;
                      }
                      store.notifyListeners();
                      if (lines.isEmpty) Navigator.pop(d);
                      set(() {});
                    }),
                    Text('${l.qty}'),
                    IconButton(icon: const Icon(Icons.add_circle_outline), onPressed: () {
                      l.qty++;
                      cart[l.pid] = l.qty;
                      store.notifyListeners();
                      set(() {});
                    }),
                  ]),
                )),
            const SizedBox(height: 8),
            TextField(controller: name, decoration: InputDecoration(labelText: isPos ? 'কাস্টমারের নাম (ঐচ্ছিক)' : 'আপনার নাম')),
            const SizedBox(height: 10),
            TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'মোবাইল নম্বর')),
            if (!isPos) ...[const SizedBox(height: 10), TextField(controller: addr, decoration: const InputDecoration(labelText: 'ডেলিভারির ঠিকানা'))],
            if (isPos) ...[
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: TextField(controller: disc, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'ছাড় (৳)'), onChanged: (_) => set(() {}))),
                const SizedBox(width: 10),
                Expanded(child: TextField(controller: paid, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: 'জমা (৳)', hintText: '${sub - dv}'))),
              ]),
            ],
            const SizedBox(height: 12),
            Text('মোট বিল: ${tk(sub - dv)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: rose)),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () {
                  if (!isPos && (name.text.trim().isEmpty || phone.text.trim().isEmpty || addr.text.trim().isEmpty)) {
                    snack(c, 'নাম, নম্বর ও ঠিকানা দিন');
                    return;
                  }
                  final o = Order(id: uid(), date: DateTime.now(), customer: name.text.trim().isEmpty ? 'সাধারণ কাস্টমার' : name.text.trim(), phone: phone.text.trim(), address: addr.text.trim(), lines: lines, discount: dv, src: isPos ? 'pos' : 'shop', status: isPos ? 'done' : 'pending');
                  o.paid = isPos ? (paid.text.isEmpty ? o.total : double.tryParse(paid.text) ?? 0) : 0;
                  if (isPos) store.takeStock(o);
                  store.orders.add(o);
                  cart.clear();
                  store.save();
                  Navigator.pop(d);
                  if (isPos) {
                    Share.share(store.memo(o));
                  } else {
                    snack(c, 'অর্ডার পাঠানো হয়েছে');
                  }
                },
                child: Padding(padding: const EdgeInsets.all(6), child: Text(isPos ? 'বিক্রি সম্পন্ন ও মেমো পাঠান' : 'অর্ডার করুন')),
              ),
            ),
          ]),
        ),
      );
    }),
  );
}

// ---------- অ্যাডমিন ----------
class Admin extends StatelessWidget {
  const Admin({super.key});
  @override
  Widget build(BuildContext c) => DefaultTabController(
        length: 3,
        child: Scaffold(
          appBar: AppBar(title: const Text('অ্যাডমিন'), bottom: const TabBar(tabs: [Tab(text: 'পণ্য'), Tab(text: 'অর্ডার'), Tab(text: 'নতুন বিক্রি')])),
          body: ListenableBuilder(listenable: store, builder: (_, __) => const TabBarView(children: [ProductsTab(), OrdersTab(), PosTab()])),
        ),
      );
}

class ProductsTab extends StatelessWidget {
  const ProductsTab({super.key});
  @override
  Widget build(BuildContext c) => Scaffold(
        backgroundColor: Colors.transparent,
        floatingActionButton: FloatingActionButton.extended(onPressed: () => form(c, null), icon: const Icon(Icons.add), label: const Text('নতুন পণ্য')),
        body: store.products.isEmpty
            ? const Center(child: Text('“নতুন পণ্য” চেপে প্রথম পণ্য যোগ করুন'))
            : ListView(padding: const EdgeInsets.fromLTRB(14, 10, 14, 90), children: store.products.map((x) => Card(
                  child: ListTile(
                    leading: thumb(x, 52),
                    title: Text(x.name),
                    subtitle: Text('কেনা ${tk(x.buy)} • বেচা ${tk(x.sell)} • লাভ ${tk(x.sell - x.buy)}\nস্টক: ${x.stock}'),
                    isThreeLine: true,
                    onTap: () => form(c, x),
                    trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async {
                      final ok = await showDialog<bool>(context: c, builder: (d) => AlertDialog(title: Text('“${x.name}” মুছবেন?'), actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('না')), FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('মুছুন'))]));
                      if (ok == true) {
                        store.products.remove(x);
                        store.save();
                      }
                    }),
                  ),
                )).toList()),
      );

  void form(BuildContext c, Product? x) {
    final n = TextEditingController(text: x?.name), ct = TextEditingController(text: x?.cat ?? 'সাধারণ');
    final b = TextEditingController(text: x == null ? '' : '${x.buy}'), s = TextEditingController(text: x == null ? '' : '${x.sell}'), st = TextEditingController(text: x == null ? '' : '${x.stock}');
    String? img = x?.img;
    showModalBottomSheet(
      context: c,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (d) => StatefulBuilder(builder: (d, set) => Padding(
            padding: EdgeInsets.fromLTRB(18, 0, 18, MediaQuery.of(d).viewInsets.bottom + 18),
            child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                GestureDetector(
                  onTap: () async {
                    final f = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 800, imageQuality: 80);
                    if (f == null) return;
                    final dir = await getApplicationDocumentsDirectory();
                    final path = '${dir.path}/${uid()}.jpg';
                    await File(f.path).copy(path);
                    set(() => img = path);
                  },
                  child: thumb(Product(id: '', name: '', img: img), 110),
                ),
                const Text('ছবি বদলাতে চাপুন'),
                const SizedBox(height: 10),
                TextField(controller: n, decoration: const InputDecoration(labelText: 'পণ্যের নাম')),
                const SizedBox(height: 10),
                TextField(controller: ct, decoration: const InputDecoration(labelText: 'ক্যাটাগরি')),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: TextField(controller: b, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'ক্রয় মূল্য'))),
                  const SizedBox(width: 10),
                  Expanded(child: TextField(controller: s, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'বিক্রয় মূল্য'))),
                ]),
                const SizedBox(height: 10),
                TextField(controller: st, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'স্টক (সংখ্যা)')),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: () {
                      if (n.text.trim().isEmpty) {
                        snack(c, 'পণ্যের নাম দিন');
                        return;
                      }
                      final p = x ?? Product(id: uid(), name: '');
                      p.name = n.text.trim();
                      p.cat = ct.text.trim().isEmpty ? 'সাধারণ' : ct.text.trim();
                      p.buy = double.tryParse(b.text) ?? 0;
                      p.sell = double.tryParse(s.text) ?? 0;
                      p.stock = int.tryParse(st.text) ?? 0;
                      p.img = img;
                      if (x == null) store.products.add(p);
                      store.save();
                      Navigator.pop(d);
                    },
                    child: const Padding(padding: EdgeInsets.all(6), child: Text('সংরক্ষণ করুন')),
                  ),
                ),
              ]),
            ),
          )),
    );
  }
}

class OrdersTab extends StatelessWidget {
  const OrdersTab({super.key});
  @override
  Widget build(BuildContext c) {
    final l = store.orders.where((o) => o.status == 'pending').toList().reversed.toList();
    if (l.isEmpty) return const Center(child: Text('কোনো নতুন অর্ডার নেই'));
    return ListView(padding: const EdgeInsets.all(14), children: l.map((o) => Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${o.customer} • ${o.phone}', style: const TextStyle(fontWeight: FontWeight.w700)),
              Text(o.address),
              const SizedBox(height: 6),
              ...o.lines.map((e) => Text('${e.name} × ${e.qty}')),
              const SizedBox(height: 6),
              Text('মোট ${tk(o.total)}', style: const TextStyle(color: rose, fontWeight: FontWeight.w800)),
              Row(children: [
                TextButton(onPressed: () {
                  o.status = 'cancel';
                  store.save();
                }, child: const Text('বাতিল')),
                const Spacer(),
                FilledButton(onPressed: () {
                  o.status = 'done';
                  store.takeStock(o);
                  store.save();
                  Share.share(store.memo(o));
                }, child: const Text('ডেলিভারি সম্পন্ন + মেমো')),
              ]),
            ]),
          ),
        )).toList());
  }
}

class PosTab extends StatelessWidget {
  const PosTab({super.key});
  @override
  Widget build(BuildContext c) {
    final n = store.pos.values.fold(0, (a, b) => a + b);
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: n == 0 ? null : FloatingActionButton.extended(onPressed: () => checkout(c, store.pos, true), icon: const Icon(Icons.point_of_sale), label: Text('বিল ($n)')),
      body: ListView(padding: const EdgeInsets.fromLTRB(14, 10, 14, 90), children: store.products.map((x) => Card(
            child: ListTile(
              leading: thumb(x, 48),
              title: Text(x.name),
              subtitle: Text('${tk(x.sell)} • স্টক ${x.stock}'),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                if ((store.pos[x.id] ?? 0) > 0) ...[
                  IconButton(icon: const Icon(Icons.remove_circle_outline), onPressed: () {
                    store.pos[x.id] = store.pos[x.id]! - 1;
                    if (store.pos[x.id] == 0) store.pos.remove(x.id);
                    store.notifyListeners();
                  }),
                  Text('${store.pos[x.id]}'),
                ],
                IconButton(icon: const Icon(Icons.add_circle, color: rose), onPressed: x.stock <= (store.pos[x.id] ?? 0) ? null : () {
                  store.pos[x.id] = (store.pos[x.id] ?? 0) + 1;
                  store.notifyListeners();
                }),
              ]),
            ),
          )).toList()),
    );
  }
}

// ---------- হিসাব ----------
class Accounts extends StatelessWidget {
  const Accounts({super.key});
  @override
  Widget build(BuildContext c) => ListenableBuilder(
        listenable: store,
        builder: (_, __) {
          final now = DateTime.now();
          bool today(DateTime d) => d.year == now.year && d.month == now.month && d.day == now.day;
          bool month(DateTime d) => d.year == now.year && d.month == now.month;
          final done = store.orders.where((o) => o.status == 'done');
          final mo = done.where((o) => month(o.date));
          final sales = mo.fold(0.0, (s, o) => s + o.total);
          final cogs = mo.fold(0.0, (s, o) => s + o.cost);
          final exp = store.expenses.where((e) => month(e.date)).fold(0.0, (s, e) => s + e.amount);
          final todaySales = done.where((o) => today(o.date)).fold(0.0, (s, o) => s + o.total);
          final dues = done.where((o) => o.due > 0.5).toList();
          final stockVal = store.products.fold(0.0, (s, p) => s + p.buy * p.stock);
          Widget box(String t, double v, [Color? col]) => Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(t, style: TextStyle(color: Theme.of(c).hintColor)), const SizedBox(height: 4), Text(tk(v), style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: col))])));
          return Scaffold(
            appBar: AppBar(title: const Text('হিসাব')),
            floatingActionButton: FloatingActionButton.extended(onPressed: () => addExpense(c), icon: const Icon(Icons.add), label: const Text('খরচ যোগ')),
            body: ListView(padding: const EdgeInsets.fromLTRB(14, 8, 14, 90), children: [
              GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, childAspectRatio: 1.7, mainAxisSpacing: 10, crossAxisSpacing: 10, children: [
                box('আজকের বিক্রি', todaySales),
                box('এ মাসের বিক্রি', sales),
                box('পণ্যের ক্রয় খরচ', cogs),
                box('অন্যান্য খরচ', exp),
                box('এ মাসের লাভ', sales - cogs - exp, sales - cogs - exp >= 0 ? Colors.green : Colors.red),
                box('স্টকের মূল্য', stockVal),
              ]),
              const SizedBox(height: 18),
              Text('কাস্টমারের বাকি (মোট ${tk(dues.fold(0.0, (s, o) => s + o.due))})', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
              if (dues.isEmpty) const Padding(padding: EdgeInsets.all(12), child: Text('কোনো বাকি নেই 🎉')),
              ...dues.map((o) => Card(child: ListTile(title: Text('${o.customer} ${o.phone}'), subtitle: Text(dstr(o.date)), trailing: TextButton(onPressed: () => receive(c, o), child: Text('বাকি ${tk(o.due)}'))))),
              const SizedBox(height: 18),
              const Text('খরচের তালিকা', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
              ...store.expenses.reversed.map((e) => Card(child: ListTile(title: Text(e.title), subtitle: Text(dstr(e.date)), trailing: Row(mainAxisSize: MainAxisSize.min, children: [Text(tk(e.amount)), IconButton(icon: const Icon(Icons.delete_outline), onPressed: () {
                    store.expenses.remove(e);
                    store.save();
                  })])))),
            ]),
          );
        },
      );

  void addExpense(BuildContext c) {
    final t = TextEditingController(), a = TextEditingController();
    showDialog(context: c, builder: (d) => AlertDialog(
          title: const Text('নতুন খরচ'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: t, decoration: const InputDecoration(labelText: 'খরচের বিবরণ')), const SizedBox(height: 10), TextField(controller: a, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'টাকা'))]),
          actions: [FilledButton(onPressed: () {
            final v = double.tryParse(a.text);
            if (t.text.trim().isEmpty || v == null) return;
            store.expenses.add(Expense(uid(), t.text.trim(), v, DateTime.now()));
            store.save();
            Navigator.pop(d);
          }, child: const Text('সংরক্ষণ'))],
        ));
  }

  void receive(BuildContext c, Order o) {
    final a = TextEditingController(text: '${o.due}');
    showDialog(context: c, builder: (d) => AlertDialog(
          title: Text('${o.customer} - টাকা নিন'),
          content: TextField(controller: a, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'টাকা')),
          actions: [FilledButton(onPressed: () {
            o.paid += double.tryParse(a.text) ?? 0;
            store.save();
            Navigator.pop(d);
          }, child: const Text('জমা করুন'))],
        ));
  }
}
